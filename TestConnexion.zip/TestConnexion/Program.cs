﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConnexion
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Connexion.Connect("modeconnexion");
                //Console.WriteLine(Connexion.getChamps_table("etudiant"));
                Dictionary<string, string> Dico = new Dictionary<string, string>();
                Dico = Connexion.getChamps_table("eleve");
                foreach (KeyValuePair<string, string> d in Dico)
                {
                    Console.WriteLine("Clé: {0}, Type: {1}", d.Key, d.Value);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.ReadKey();
            }
        }
    }
}
